// Variabel penyimpanan todo
let todos = [];

// Event listener form submit
document.getElementById("todo-form").addEventListener("submit", function (e) {
  e.preventDefault(); // mencegah reload halaman
  validateInput();
});

// Tombol Delete All
document.querySelector(".bg-red-500").addEventListener("click", deleteAllTodo);

// Tombol Filter
document.querySelector(".bg-green-500").addEventListener("click", filterTodo);

function validateInput() {
  const todoInputEl = document.getElementById("todo-input");
  const dueDateInputEl = document.getElementById("due-date-input");

  const todoInput = todoInputEl.value.trim();
  const dueDateInput = dueDateInputEl.value;

  if (todoInput === "" || dueDateInput === "") {
    alert("Please fill in all fields.");
    return; // langsung stop biar tidak lanjut
  }

  addTodo(todoInput, dueDateInput);

  // reset form setelah berhasil
  document.getElementById("todo-form").reset();
}

function addTodo(task, dueDate) {
  const todoItem = {
    task,
    dueDate,
    complete: false,
  };
  todos.push(todoItem);
  renderTodoList();
}

function deleteAllTodo() {
  todos = [];
  renderTodoList();
}

function deleteTodo(index) {
  todos.splice(index, 1);
  renderTodoList();
}

function toggleComplete(index) {
  todos[index].complete = !todos[index].complete;
  renderTodoList();
}

function filterTodo() {
  // contoh: hanya tampilkan yang belum complete
  const filtered = todos.filter((t) => !t.complete);
  renderTodoList(filtered);
}

function renderTodoList(list = todos) {
  const todoListContainer = document.getElementById("todo-list");
  todoListContainer.innerHTML = "";

  if (list.length === 0) {
    todoListContainer.innerHTML = `<p>No tasks added yet.</p>`;
    return;
  }

  list.forEach((item, index) => {
    const li = document.createElement("li");
    li.className =
      "flex justify-between items-center bg-gray-800 text-white rounded px-4 py-2 mb-2";

    li.innerHTML = `
      <div>
        <p class="${item.complete ? "line-through text-gray-400" : ""}">
          ${item.task} - <span class="text-sm text-gray-300">${item.dueDate}</span>
        </p>
      </div>
      <div class="flex gap-2">
        <button onclick="toggleComplete(${index})" class="bg-green-500 hover:bg-green-600 px-2 py-1 rounded text-sm">
          ${item.complete ? "Undo" : "Complete"}
        </button>
        <button onclick="deleteTodo(${index})" class="bg-red-500 hover:bg-red-600 px-2 py-1 rounded text-sm">
          Delete
        </button>
      </div>
    `;

    todoListContainer.appendChild(li);
  });
}

// Render awal
renderTodoList();
